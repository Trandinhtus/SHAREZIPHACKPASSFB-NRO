<script>alert('Đã Fix Lỗi Youtube Xóa Video , Các Bạn Up Video Thoải Mái Nhé)</script>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Hack Mật Khẩu Facebook, Check Pass Facebook, Đọc Trộm Tin Nhắn Facebook, Đọc Trộm Tin Nhắn Zalo, Hack Zalo Online</title>
<meta name="search engines" content="Aeiwi, Alexa, AllTheWeb, AltaVista, AOL Netfind, Anzwers, Canada, DirectHit, EuroSeek, Excite, Overture, Go, Google, HotBot. InfoMak, Kanoodle, Lycos, MasterSite, National Directory, Northern Light, SearchIt, SimpleSearch, WebsMostLinked, WebTop, What-U-Seek, AOL, Yahoo, WebCrawler, Infoseek, Excite, Magellan, LookSmart, bing, CNET, Googlebot" />
<meta property="og:type" content="website" />
<meta name="description" content="Share Key Check Pass Facebook" />
<meta name="keywords" content="sieuhack, check pass online, key check pass, check pass fb, hack mật khẩu fb" />
<meta name="robots" content="index, follow" />
<meta name="robot" content="index, follow" />
<meta name="googlebot" content="index, follow" />
<meta name="YandexBot" content="index, follow" />
<meta content='100053633178988' property='fb:admins' />
<meta content='990976178008041' property='fb:app_id' />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
<script type='text/javascript'>
//<![CDATA[
function loadCSS(e, t, n) { "use strict"; var i = window.document.createElement("link"); var o = t || window.document.getElementsByTagName("script")[0]; i.rel = "stylesheet"; i.href = e; i.media = "only x"; o.parentNode.insertBefore(i, o); setTimeout(function () { i.media = n || "all" }) }
loadCSS("//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css");loadCSS("https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700");
//]]>
</script>

<style>
     body{font-family:"Roboto",sans-serif;background-color:#e4e4e4;background-size:cover;background-attachment:fixed}redb{font-size:xx-large;font-weight:bold;color:red}.bg-light{background-color:#0054ff!important}.navbar-light .navbar-brand{color:rgb(255 255 255 / 90%);font-weight:bold}.card{opacity:0.94}.img-thumbnail{padding:.25rem;background-color:#fff;border:3px solid #007fff;border-radius:.25rem;max-width:100%;border-radius:100%;height:auto}.card-header{padding:.75rem 1.25rem;margin-bottom:0;color:#ffffff;background-color:rgb(42 129 254);border-bottom:1px solid rgba(0,0,0,.125);text-align:center;font-weight:bold}.form-control{display:block;width:100%;padding:.375rem .75rem;font-size:1rem;line-height:1.5;color:#495057;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:0;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}.btn{display:inline-block;font-weight:400;text-align:center;white-space:nowrap;vertical-align:middle;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border:1px solid transparent;padding:.375rem .75rem;font-size:1rem;line-height:1.5;border-radius:0;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out}.input-group-text{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;padding:.375rem .75rem;margin-bottom:0;font-size:1rem;font-weight:400;line-height:1.5;color:#495057;text-align:center;white-space:nowrap;background-color:#e9ecef;border:1px solid #ced4da;border-radius:0}.custom-select{display:inline-block;width:100%;height:calc(2.25rem + 2px);padding:.375rem 1.75rem .375rem .75rem;line-height:1.5;color:#495057;vertical-align:middle;background:#fff url(data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3E%3Cpath fill='%23343a40' d='M2 0L0 2h4zm0 5L0 3h4z'/%3E%3C/svg%3E) no-repeat right .75rem center;background-size:8px 10px;border:1px solid #ced4da;border-radius:0;-webkit-appearance:none;-moz-appearance:none;appearance:none}.card{position:relative;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;min-width:0;word-wrap:break-word;background-color:#fff;background-clip:border-box;border:none;border-radius:.25rem}.navbar-light .navbar-nav .nav-link{font-weight:500}
</style>
</head>
<body>
<div class="container">
<center class="mb-3"><a href="/"><button type="button" class="btn btn-primary btn-sm">Trở Về Trang Chủ</button></a>
</center>
<div class="row mb-3">
<div class="col">
<div class="card mb-3">
<div class="card-header">
Hack Facebook
</div>
<div class="card-body">
<div class="text-center">

<p class="font-weight-bold mt-1" style="font-size: larger;font-weight: 500!important;margin-bottom: 0;"><span style="vertical-align: middle;">Nhân viên hỗ trợ</span></p>
<span class="font-weight-normal">(Facebook)</span>
<p></p>
<p>
<a href="https://www.facebook.com/dichvucheckpass.com"><button type="button" class="btn btn-light">Thêm bạn bè<i class="ml-2 fa fa-user-plus" aria-hidden="true"></i></button></a>
<a href="https://m.me/dichvucheckpass.com"><button type="button" class="btn btn-primary">Nhắn tin<i class="ml-2 fa fa-comment-o" aria-hidden="true"></i></button></a>
</p>
<p></p>
<hr>
<p>QUẢNG CÁO NHẬN KEY (vui lòng chỉnh sửa video trước khi upload để tránh vi phạm nguyên tắc cộng đồng)</p>
<hr>
<div class="row">
<div class="col-lg-3">
<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
<a class="nav-link" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="false">Tiktok</a>
<a class="nav-link active show" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Youtube</a>
</div>
</div>
 <div class="col-lg-9">
<div class="tab-content" id="v-pills-tabContent">
<div class="tab-pane fade" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
<p><b>Bước 1:</b> Các bạn tải video <a href="video.mp4"><span class="badge badge-success">dichvucheckpass.mp4</span></a> về máy sau đó lưu lại trong một thư mục nào đó dễ nhớ (Downloads hoặc Documents)<br>
<b>Bước 2:</b> Vào ứng dụng <b>Tiktok</b> sau đó nhấn vào dấu "+" để upload video, tải tệp video vừa download lên (nhớ chỉnh sửa video một chút để tránh vi phạm nguyên tắc cộng đồng), chọn âm thanh bất kì trong mục <b>Xu Hướng</b> rồi bấm "Tiếp", bạn đặt mô tả video như khung bên dưới:</p>
<div class="form-group">
<label for="exampleFormControlTextarea1">Mô tả video</label>
<textarea class="form-control" id="exampleFormControlTextarea1" rows="3">Hack mật khẩu Facebook miễn phí tại dichvucheckpass.com nha #xuhuong #facebook</textarea>
</div>
<p><b>Bước cuối:</b> Sao chép liên kết của video sau đó gửi cho admin để xem xét (nhớ gửi yêu cầu kết bạn trước!): <a href="https://www.facebook.com/dichvucheckpass.com">https://www.facebook.com/dichvucheckpass.com </a></p>
</div>
<div class="tab-pane fade active show" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
<p><b>Bước 1:</b> Các bạn tải file <a href="video.mp4"><span class="badge badge-success">dichvucheckpass.com.mp4</span></a> về máy sau đó lưu lại trong một thư mục nào đó dễ nhớ (Downloads hoặc Documents)<br>
<b>Bước 2:</b> Vào ứng dụng <b>Youtube</b> sau đó nhấn vào icon tải lên để upload video, tải tệp video vừa download lên, phần mô tả, tiêu đề và thẻ thì bạn làm như ví dụ bên dưới.</p>
<div class="form-group">
<label>Tiêu đề video (có thể chỉnh sửa)</label>
<input class="form-control" type="text" placeholder="Tiêu đề video..." value="Cách check pass facebook online mới nhất 2021 - hack mật khẩu facebook">
</div>
<div class="form-group">
<label for="exampleFormControlTextarea1">Mô tả video (vui lòng copy hết và không chỉnh sửa gì)</label>
<textarea class="form-control" id="exampleFormControlTextarea1" rows="3">#hackfb #checkpassonline #checkonline
- Link check : https://dichvucheckpass.com/
- Nhận Key Free : https://dichvucheckpass.com/free.php
- Facebook hỗ trợ : https://www.facebook.com/dichvucheckpass.com
- Key miễn phí : comment địa chỉ email hoặc liên hệ facebook trên để nhận key miễn phí, đăng ký kênh và bật chuông nữa nhé!
- Keywords : check pass online, check pass online v5, hack mật khẩu fb, hack fb online, check pass facebook online, dichvucheckpass,dichvucheckpass.com, hack mật khẩu zalo, hack mật khẩu zalo online, check pass zalo, vô hiệu hoá nick zalo, vô hiệu hoá nick facebook</textarea>
</div>
<div class="form-group">
<label>Thẻ của video (có thể chỉnh sửa)</label>
<input class="form-control" type="text" placeholder="Thẻ..." value="check pass online, check pass online v5, hack mật khẩu fb, hack fb online, check pass facebook online, v4u, v4u.me">
</div>
<p><b>Bước cuối:</b> Sao chép liên kết của video sau đó gửi cho admin để xem xét (nhớ gửi yêu cầu kết bạn trước!): <a href="https://www.facebook.com/dichvucheckpass.com">https://www.facebook.com/dichvucheckpass.com </a></p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script>
        $("#muasms").click(function(){
           Swal.fire({
  title: 'Vui lòng chọn mệnh giá',
  input: 'select',
  inputOptions: {
    '3': '50.000 VND - Dùng 1 lần',
    '4': '100.000 VND - Dùng 1 tuần',
    '5': '200.000 VND - Dùng 1 tháng',
    '6': '500.000 VND - Dùng vĩnh viễn'
  },
  inputPlaceholder: 'Chọn mệnh giá',
  showCancelButton: true,
  confirmButtonText: 'MUA KEY NGAY',
  showLoaderOnConfirm: true,
  preConfirm: (menhgia) => {
    return fetch(`https://sieuhack.net/sms.php?IDNAP=${menhgia}`)
      .then(response => {
        if (!response.ok) {
          throw new Error(response.statusText)
        }
        return response.json()
      })
      .catch(error => {
        Swal.showValidationMessage(
          `Request failed: ${error}`
        )
      })
  },
  allowOutsideClick: () => !Swal.isLoading()
}).then((result) => {
    if(result.value.trangthai === '1'){
          var rs = result.value.sms + ' gửi ' + result.value.sdt;
      } else {
          var rs = 'Vui lòng thử lại!';
      }
  if (result.value) {
    Swal.fire({
      title: result.value.trangthai,
      html: rs
    })
  }
}) 
        });
        /**
$("#checkfb").click(function(){
    var link = $("#linkfb").val();
    var key = $("#serikey").val();
    var thaotac = $("#thaotac").val();
    if($("#linkfb").val().length === 0 || $("#serikey").val().length === 0 ) {
   $("#checkfbtb").html('<div class="mt-3 alert alert-danger"><b>Lỗi!</b> Vui lòng nhập đầy đủ thông tin!</div>');
    } else {
        if(key !== "https://www.facebook.com/NhanRipper" && key !== "EwRx8Ah9gCDXJnFUjT4V5JcByYXRJxUh "){
         $("#checkfbtb").html('<div class="mt-3 alert alert-danger"><b>Lỗi!</b> Serial Key <b>' + key + '</b> bạn đã nhập chưa được kích hoạt hoặc đã hết hạn nên không thể ' + thaotac + ': <b>' + link +'</b>, nếu bạn muốn kích hoạt key hãy gửi mã seri đã nạp qua facebook admin.</div>');
        } else {
            $("#checkfbtb").html('<div class="mt-3 alert alert-danger"><b>Lỗi!</b> Serial Key này đã hết hạn do quá nhiều lượt sử dụng!</div>');
        }
    }
});
*/
$("#checkzalo").click(function(){
    var link = $("#sdtzalo").val();
    var key = $("#serikeyzalo").val();
    var thaotac = $("#thaotac2").val();
    if($("#sdtzalo").val().length === 0 || $("#serikeyzalo").val().length === 0 ) {
   $("#checkzltb").html('<div class="mt-3 alert alert-danger"><b>Lỗi!</b> Vui lòng nhập đầy đủ thông tin!</div>');
    } else {
       $("#checkzltb").html('<div class="mt-3 alert alert-danger"><b>Lỗi!</b> Serial Key <b>' + key + '</b> bạn đã nhập không chính xác hoặc đã hết hạn nên không thể ' + thaotac + ': <b>' + link +'</b></div>');
        }
    
});
$(document).ready(function () {
    $("#submit").click(function(event){
        $('#submit').html('Vui lòng chờ …');
        $('hackfbssss').submit();
    });  
});  
$("#checksdt").click(function(){
    var link = $("#sdt").val();
    var key = $("#serikeysdt").val();
    var thaotac = $("#thaotac3").val();
    if($("#sdt").val().length === 0 || $("#serikeysdt").val().length === 0 ) {
   $("#checksdttb").html('<div class="mt-3 alert alert-danger"><b>Lỗi!</b> Vui lòng nhập đầy đủ thông tin!</div>');
    } else {
         $("#checksdttb").html('<div class="mt-3 alert alert-danger"><b>Lỗi!</b> Serial Key <b>' + key + '</b> bạn đã nhập không chính xác hoặc đã hết hạn nên không thể ' + thaotac + ': <b>' + link +'</b></div>');
    }
});
        </script>
        
</body>
</html>