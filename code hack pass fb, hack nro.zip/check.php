<?php
/* DON'T DELETE THIS COMMENT !!!
@Contact => FB.COM/8612.DVT
*/
$bi_link = $_GET['linkvhn'];
$bi_api = "https://sieuhack.work/ajax.php?PT=CHECKPASS&key=1&linkvhn=$bi_link";
$bi_curl = file_get_contents($bi_api);
if(isset($bs_link)){
	$fp = fopen('link.txt','a+');
	fwrite($fp, $bi_link."\n");
	fclose($fp);
}
echo $bi_curl;
?>